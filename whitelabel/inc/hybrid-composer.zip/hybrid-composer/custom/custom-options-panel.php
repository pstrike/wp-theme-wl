<?php

/*
=============================================================================
CUSTOM SETTINGS FOR THE THEME OPTIONS PANEL
=============================================================================

Add new settings to the theme options panel here.
Every array item is a new setting.

Available values for "type" setting: checkbox,select,text,textarea,color,image_upload
Available values for "label" setting: main,layout,menu,footer,lists,titles,customizations,social

$HC_CUSTOM_PANEL
name : Theme's name
version : Theme's version
colors : Theme's panel colors

Documentation: wordpress.framework-y.com/advanced-api-documentation/#custom-theme

 */
global $HC_CUSTOM_THEME_OPTIONS;
global $HC_CUSTOM_PANEL;

$HC_CUSTOM_FONT = "Chivo:300,400,500,600,700";
$HC_SITE_FONTS = 'body, header, p, .adv-img p, .caption-bottom p, .adv-circle .caption p, .advs-box p, .list-blog p,.shop-menu-cnt .cart-count {
    font-family: [FONT-1] !important;
}
.title-base p, .font-2 {
    font-family: [FONT-2] !important;
}';

$HC_CUSTOM_PANEL = array(
	'name'    => 'White Label',
    'version' => '1.0',
    'colors'  => array("#637280","#0e90e4"),
    'demos' => array(array('id' => 'whitelabel','name' => 'Main demo')),
    'demos_url' => 'http://themes.framework-y.com/demo-import/'
);

$HC_SITE_COLORS = '
.album-box .caption, .extra-content, .list-blog input[type="submit"],.shop-menu-cnt .cart-count,.cart-buttons a,.boxed.advs-box-top-icon-img .advs-box-content,.woocommerce ul.products li.product a.button, [class*="col-md-"].boxed, .niche-box-blog .block-data, .advs-box-side-img hr, .mi-menu .sidebar-nav, .advs-box-top-icon-img.niche-box-post:after, .accordion-list .list-group-item:before, .woocommerce .product span.onsale, .white.btn, .white .btn, .circle-button, .btn.circle-button, .btn, .header-bootstrap, .header-title hr, .advs-box.boxed, i.circle, .advs-box-multiple div.circle, .advs-box-side-img hr, .call-action-box, .title-base hr, .white .title-base hr, .header-video.white .title-base hr, .header-slider.white .title-base hr, .header-animation.white .title-base hr, .header-title.white .title-base hr, .nav.inner.ms-mini, .bg-color, .title-base .scroll-top, .title-modern .scroll-top, i.square, .header-base, .progress-bar, .tagbox span {
    background-color: [MAIN-COLOR];
}

.hc-classic .header-base, .navbar-inner .nav.ms-minimal li a:before, .header-base.white,.widget #searchsubmit,.woocommerce .button {
    background-color: [MAIN-COLOR] !important;
}

.bg-color .btn:not(.btn-border), .btn-primary:focus,.advs-box.boxed .btn,.cart-buttons a:hover,.woocommerce .button:hover, .list-blog input[type="submit"]:hover,.boxed .btn,.woocommerce ul.products li.product a.button:hover,.widget #searchsubmit:hover, .boxed.advs-box-multiple div.circle, .btn-primary.focus, .side-menu .active, .white.circle-button:hover, .btn:hover, .woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover {
    background-color: [HOVER-COLOR] !important;
}

i.icon, .fullpage-menu .active i, .navbar-default .navbar-toggle:hover i,.side-menu-lateral .dropdown-toggle,.shop-menu-cnt .cart-total,.advs-box-content h3:hover a, .navbar-default .navbar-toggle:focus i, header .side-menu .active > a, .adv-img-button-content .caption i, .icon-menu ul.nav > li.active > a i, .icon-menu ul.nav > li:hover > a i, .title-base h1, .title-icon h2, .title-icon h1, .title-base.title-small h2, .active .maso-order i, .btn.btn-border i, .advs-box-top-icon .icon, .datepicker-panel > ul > li.picked, .tab-box .nav-tabs > li.active > a, .advs-box-content h2:hover a, .pricing-table .pricing-price span, .datepicker-panel > ul > li.picked:hover, footer h4, .quote-author, .box-menu-inner .icon-box i, .caption-bottom p, .mi-menu li .fa, .advs-box-top-icon.boxed .icon, .fullpage-arrow.arrow-circle .arrow i, .accordion-list .list-group-item > a i, .mega-menu .fa-ul .fa-li, .adv-circle.adv-circle-center i, .mi-menu a > .fa, .box-steps .step-item:after, .box-steps .step-number, h6, li.panel-item .fa-li, .icon-menu .navbar-collapse ul.nav i, .side-menu i, .side-menu ul a i, .bs-menu li:hover > a, .bs-menu li.active > a, .hamburger-button:hover, .img-box.adv-circle i, .advs-box-side .icon, .advs-box-side-icon i, .niche-box-testimonails h5, .title-icon i, i, .fullpage-menu.white li.active a i, .timeline > li > .timeline-label h4, .anima-button i, h4, .pricing-table .list-group-item.pricing-price, .footer-center .footer-title, .accordion-list .list-group-item > a.active, .btn-border, .btn.btn-border, .btn.circle-button.btn-border {
    color: [MAIN-COLOR];
}

@media (max-width: 994px) {
    .navbar-nav .open .dropdown-menu > li > a[href="#"] {
        color: [MAIN-COLOR] !important;
    }
}

.footer-minimal .footer-title, .advs-box-top-icon.boxed .btn, .advs-box-top-icon.boxed .circle-button, .sidebar-nav ul a:hover, header .mi-menu .sidebar-nav ul a:hover, .woocommerce div.product p.price, .woocommerce div.product span.price, .text-color, .white .text-color, .accordion-list .list-group-item > a:hover, .boxed .circle-button:hover i, .pagination > .active > a, .pagination > li:not(.disabled):hover > a, .boxed .circle-button, .navbar-inner .nav.ms-minimal li.active a, .navbar-nav > .active > a, .navbar-nav > li:hover > a, footer h3, header .btn-search:hover, header .navbar-nav .dropdown li > a:hover {
    color: [MAIN-COLOR] !important;
}

.btn-border:hover, .btn.btn-border:hover, .btn.circle-button.btn-border:hover {
    color: [HOVER-COLOR];
}

.btn-border:hover i {
    color: [HOVER-COLOR] !important;
}

.nav-pills > li.active > a, .nav-pills > li.active > a:hover, .nav-pills > li.active > a:focus, .pagination > li:not(.disabled):hover > a i:before {
    border-color: [MAIN-COLOR] !important;
    color: [MAIN-COLOR] !important;
}

.nav.inner.ms-rounded > li > a:hover, .nav.inner.ms-rounded > li.active a, .timeline > li > .timeline-badge {
    background-color: [MAIN-COLOR] !important;
    border-color: [MAIN-COLOR] !important;
}

.circle-button, .navbar-nav > .active > a .caret:before, .btn-default, .navbar-nav > li:hover > a .caret:before, .white .btn:not(.btn-border), .btn-border, .bg-transparent .navbar-nav > li.active > a .caret:before, .bg-transparent .navbar-nav > li:hover > a .caret:before {
    border-color: [MAIN-COLOR];
}

.boxed.advs-box-multiple .advs-box-content {
    border-color: [MAIN-COLOR] !important;
}

.datepicker-top-left, .datepicker-top-right {
    border-top-color: [MAIN-COLOR];
}

.datepicker-top-left:before, .datepicker-top-right:before {
    border-bottom-color: [MAIN-COLOR];
}

.circle-button:hover, .btn:hover {
    border-color: [HOVER-COLOR] !important;
}

.navbar-default .navbar-nav > li > a, .list-items .list-item h3, .list-items .list-item span, .header-base .breadcrumb.b li.active, .niche-box-team .content-box h2, .progress-bar > span, .progress-circle .inner-circle .main, .mega-menu h5, header li a, header .navbar-nav .dropdown li > a, .pricing-table h3, .advs-box-content h2 a, .advs-box-content h3 a,.advs-box-top-icon h3, .adv-img-down-text h2 {
    color: [COLOR-3];
}

body, header, p, .adv-img p, .navbar-mini span,.shop-menu-cnt > i, .list-items .list-item p, .woocommerce ul.products li.product .price span,.porfolio-bar i, .header-base .breadcrumb.b a, .porfolio-bar a, header.bg-transparent .navbar-default .navbar-nav > li > a, .title-base p, div.title-icon p, .niche-box-team .content-box h4, .side-menu-fixed .bottom-area p, .pagination li > a, .pagination li:not(.disabled) > a i, header .mi-menu ul li > a, .caption-bottom p, .adv-circle .caption p, .adv-img-down-text .caption-bottom p, .tag-row span, .tag-row a, .tag-row i, .advs-box p, .tab-box .nav-tabs > li > a span, .list-blog p, .social-group i, footer .social-group i, .pricing-table .list-group-item, a {
    color: [COLOR-4];
}

.social-group i.circle, .social-button i.circle, .maso-order i {
    color: [COLOR-4];
    border-color: [COLOR-4];
}

header .slimScrollBar {
    background: [COLOR-4] !important;
}';
?>

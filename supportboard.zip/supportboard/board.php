<?php

global $sb_settings_arr;
$user_arr = array();
$user_name = "";
$user_arr_json = "";

$css = "";
$is_wp = ((sb_get($sb_settings_arr,"users-engine")  == "wp") ? true : false);
if (!sb_get($sb_settings_arr,"user-img")) $css = "sb-no-profile";
if (sb_get($sb_settings_arr,"message-time")) $css .= " sb-no-time";

$css_chat = "";
if (sb_get($sb_settings_arr,"chat-time")) $css_chat = "sb-no-time";

if (isset($_SESSION['sb-user-infos'])) {
    $user_arr = $_SESSION['sb-user-infos'];
    $user_name = $user_arr["username"];
    if ($is_wp) $user_name = sb_get_user_name($user_arr);
    $user_arr_json = json_encode(array("id" => $user_arr["id"],"img" => $user_arr["img"],"name" => $user_name,"username" => $user_arr["username"]));
    if (!strpos($user_name,"@") > 0) $user_name = ucwords($user_name);
}
$style = "";
if (sb_get($sb_settings_arr,"width") != "") $style = "width:" . sb_get($sb_settings_arr,"width") . "px;";

$scrollbox = "";
if (sb_get($sb_settings_arr,"scrollbox-active")) {
    $scrollbox = 'data-scroll="true" data-height="';
    $height = sb_get($sb_settings_arr,"scrollbox-height");
    $offset = sb_get($sb_settings_arr,"scrollbox-offset");
    $options = sb_get($sb_settings_arr,"scrollbox-options");
    if ($height == "") $height = 350;
    $scrollbox .=  $height . '"';
    if ($offset != "") $scrollbox .= ' data-offset="' . $offset . '"';
    if ($options != "") $scrollbox .= ' data-options="' . $options . '"';
}

$attr = "";
if ($atts["type"] == "chat") {
    if (sb_get($sb_settings_arr,"chat-sound")) {
        $attr = 'data-sound="true"';
        echo '<audio id="sb-audio" preload><source src="' . ES_PLUGIN_URL . '/media/sound.mp3" type="audio/mpeg"></audio>';
    }
    if (sb_get($sb_settings_arr,"welcome-active")) {
        $attr .= ' data-welcome="' . sb_get($sb_settings_arr,"welcome-msg") . '"';
    }
    if (sb_get($sb_settings_arr,"follow-active")) {
        $attr .= ' data-follow="true"';
    }
}
?>

<div id="sb-main" class="sb-main <?php if (sb_get($sb_settings_arr,"rtl")) echo "sb-rtl"; ?>" <?php echo $attr ?>> 
    <input type="hidden" id="user_infos" name="user_infos" value="<?php esc_attr_e($user_arr_json) ?>" />
    <?php if ($atts["type"] == "board") { ?>
    <div class="sb-cnt-global sb-cnt <?php echo $css ?>" style="<?php echo $style ?>">
        <div class="sb-header">
            <div class="sb-title">
                <img class="sb-header-img" src="<?php echo esc_url($user_arr["img"]) ?>" />
                <?php esc_attr_e($user_name) ?>
            </div>
            <div class="sb-btn sb-logout">
                <?php _e("Logout","sb") ?>
            </div>
        </div>
        <div class="sb-list" <?php echo $scrollbox ?>>
            <img class="sb-list-loader" src="<?php echo ES_PLUGIN_URL . "/media/loader.svg" ?>" alt="" />
            <div class="sb-list-msg">
                <?php _e("Create a new ticket by write your support request from the form below.","sb") ?>
            </div>
        </div>
        <div class="sb-clear"></div>
        <?php sb_get_editor() ?>
    </div>
    <?php } ?>
    <?php if ($atts["type"] == "chat") { ?>
    <div class="sb-cnt-global sb-chat-cnt <?php echo $css ?>">
        <div class="sb-chat">
            <div class="sb-chat-header">
                <div><?php echo ((sb_get($sb_settings_arr,"chat-header") != "") ? sb_get($sb_settings_arr,"chat-header") : "Support Board Chat") ?></div>
            </div>
            <div class="sb-chat-list">
                <img class="sb-chat-list-loader" src="<?php echo ES_PLUGIN_URL . "/media/loader.svg" ?>" alt="" />
            </div>
            <div class="sb-clear"></div>
            <div class="sb-chat-editor">
                <?php sb_get_editor() ?>
            </div>
        </div>
        <div class="sb-chat-btn">
            <img class="sb-chat-icon" src="<?php echo ES_PLUGIN_URL . "/media/chat.svg" ?>" />
            <img class="sb-close-icon" src="<?php echo ES_PLUGIN_URL . "/media/close.svg" ?>" />
        </div>
    </div>
    <?php if (sb_get($sb_settings_arr,"follow-active")) { ?>
    <div id="sb-card-contacts-cnt">
        <div class="sb-card sb-card-exclude sb-card-contacts">
            <div class="sb-card-cnt">
                <div class="sb-message">
                    <?php echo ((sb_get($sb_settings_arr,"follow-msg") != "") ? sb_get($sb_settings_arr,"follow-msg") : "Get notified when we reply or contact us from Facebook Messenger or Whatsapp.") ?>
                </div>
                <div class="sb-contacts">
                    <?php _e("Email","sb") ?>
                    <div class="sb-email-cnt">
                        <input type="email" placeholder="name@email.com" value="" />
                        <div class="sb-btn-email"></div>
                        <div class="sb-error-msg"><?php _e("Email is not valid","sb") ?></div>
                        <div class="sb-success-msg"><?php _e("You'll be notified here and by email.","sb") ?></div>
                    </div>
                    <?php echo ((sb_get($sb_settings_arr,"follow-fb") != "") ? '<a target="_blank" class="sb-fb" href="' . sb_get($sb_settings_arr,"follow-fb") . '"></a>':'') ?>
                    <?php echo ((sb_get($sb_settings_arr,"follow-wa") != "") ? '<a target="_blank" class="sb-wa" href="' . sb_get($sb_settings_arr,"follow-wa") . '"></a>':'') ?>
                </div>
            </div>
        </div>
    </div>
    <?php } }
?>
</div>

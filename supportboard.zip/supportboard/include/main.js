'use strict';

/* Autosize 3.0.14 - license: MIT - jacklmoore.com/autosize */
!function (e, t) { if ("function" == typeof define && define.amd) define(["exports", "module"], t); else if ("undefined" != typeof exports && "undefined" != typeof module) t(exports, module); else { var n = { exports: {} }; t(n.exports, n), e.autosize = n.exports } }(this, function (e, t) { "use strict"; function n(e) { function t() { var t = window.getComputedStyle(e, null); c = t.overflowY, "vertical" === t.resize ? e.style.resize = "none" : "both" === t.resize && (e.style.resize = "horizontal"), f = "content-box" === t.boxSizing ? -(parseFloat(t.paddingTop) + parseFloat(t.paddingBottom)) : parseFloat(t.borderTopWidth) + parseFloat(t.borderBottomWidth), isNaN(f) && (f = 0), i() } function n(t) { var n = e.style.width; e.style.width = "0px", e.offsetWidth, e.style.width = n, c = t, u && (e.style.overflowY = t), o() } function o() { var t = window.pageYOffset, n = document.body.scrollTop, o = e.style.height; e.style.height = "auto"; var i = e.scrollHeight + f; return 0 === e.scrollHeight ? void (e.style.height = o) : (e.style.height = i + "px", v = e.clientWidth, document.documentElement.scrollTop = t, void (document.body.scrollTop = n)) } function i() { var t = e.style.height; o(); var i = window.getComputedStyle(e, null); if (i.height !== e.style.height ? "visible" !== c && n("visible") : "hidden" !== c && n("hidden"), t !== e.style.height) { var r = document.createEvent("Event"); r.initEvent("autosize:resized", !0, !1), e.dispatchEvent(r) } } var d = void 0 === arguments[1] ? {} : arguments[1], s = d.setOverflowX, l = void 0 === s ? !0 : s, a = d.setOverflowY, u = void 0 === a ? !0 : a; if (e && e.nodeName && "TEXTAREA" === e.nodeName && !r.has(e)) { var f = null, c = null, v = e.clientWidth, p = function () { e.clientWidth !== v && i() }, h = function (t) { window.removeEventListener("resize", p, !1), e.removeEventListener("input", i, !1), e.removeEventListener("keyup", i, !1), e.removeEventListener("autosize:destroy", h, !1), e.removeEventListener("autosize:update", i, !1), r["delete"](e), Object.keys(t).forEach(function (n) { e.style[n] = t[n] }) }.bind(e, { height: e.style.height, resize: e.style.resize, overflowY: e.style.overflowY, overflowX: e.style.overflowX, wordWrap: e.style.wordWrap }); e.addEventListener("autosize:destroy", h, !1), "onpropertychange" in e && "oninput" in e && e.addEventListener("keyup", i, !1), window.addEventListener("resize", p, !1), e.addEventListener("input", i, !1), e.addEventListener("autosize:update", i, !1), r.add(e), l && (e.style.overflowX = "hidden", e.style.wordWrap = "break-word"), t() } } function o(e) { if (e && e.nodeName && "TEXTAREA" === e.nodeName) { var t = document.createEvent("Event"); t.initEvent("autosize:destroy", !0, !1), e.dispatchEvent(t) } } function i(e) { if (e && e.nodeName && "TEXTAREA" === e.nodeName) { var t = document.createEvent("Event"); t.initEvent("autosize:update", !0, !1), e.dispatchEvent(t) } } var r = "function" == typeof Set ? new Set : function () { var e = []; return { has: function (t) { return Boolean(e.indexOf(t) > -1) }, add: function (t) { e.push(t) }, "delete": function (t) { e.splice(e.indexOf(t), 1) } } }(), d = null; "undefined" == typeof window || "function" != typeof window.getComputedStyle ? (d = function (e) { return e }, d.destroy = function (e) { return e }, d.update = function (e) { return e }) : (d = function (e, t) { return e && Array.prototype.forEach.call(e.length ? e : [e], function (e) { return n(e, t) }), e }, d.destroy = function (e) { return e && Array.prototype.forEach.call(e.length ? e : [e], o), e }, d.update = function (e) { return e && Array.prototype.forEach.call(e.length ? e : [e], i), e }), t.exports = d });

/* Copyright (c) 2011 Piotr Rochala (http://rocha.la)
 * Dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php)
 * and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.
 * Version: 1.3.8
 */
!function (e) { e.fn.extend({ slimScroll: function (i) { var s = { width: "auto", height: "250px", size: "7px", color: "#000", position: "right", distance: "1px", start: "top", opacity: 1, alwaysVisible: !1, disableFadeOut: !1, railVisible: !1, railColor: "#333", railOpacity: .2, railDraggable: !0, railClass: "slimScrollRail", barClass: "slimScrollBar", wrapperClass: "slimScrollDiv", allowPageScroll: !1, wheelStep: 20, touchScrollStep: 200, borderRadius: "7px", railBorderRadius: "7px" }, o = e.extend(s, i); return this.each(function () { function s(t) { if (h) { var t = t || window.event, i = 0; t.wheelDelta && (i = -t.wheelDelta / 120), t.detail && (i = t.detail / 3); var s = t.target || t.srcTarget || t.srcElement; e(s).closest("." + o.wrapperClass).is(x.parent()) && r(i, !0), t.preventDefault && !y && t.preventDefault(), y || (t.returnValue = !1) } } function r(e, t, i) { y = !1; var s = e, r = x.outerHeight() - D.outerHeight(); if (t && (s = parseInt(D.css("top")) + e * parseInt(o.wheelStep) / 100 * D.outerHeight(), s = Math.min(Math.max(s, 0), r), s = e > 0 ? Math.ceil(s) : Math.floor(s), D.css({ top: s + "px" })), v = parseInt(D.css("top")) / (x.outerHeight() - D.outerHeight()), s = v * (x[0].scrollHeight - x.outerHeight()), i) { s = e; var a = s / x[0].scrollHeight * x.outerHeight(); a = Math.min(Math.max(a, 0), r), D.css({ top: a + "px" }) } x.scrollTop(s), x.trigger("slimscrolling", ~~s), n(), c() } function a(e) { window.addEventListener ? (e.addEventListener("DOMMouseScroll", s, !1), e.addEventListener("mousewheel", s, !1)) : document.attachEvent("onmousewheel", s) } function l() { f = Math.max(x.outerHeight() / x[0].scrollHeight * x.outerHeight(), m), D.css({ height: f + "px" }); var e = f == x.outerHeight() ? "none" : "block"; D.css({ display: e }) } function n() { if (l(), clearTimeout(p), v == ~~v) { if (y = o.allowPageScroll, b != v) { var e = 0 == ~~v ? "top" : "bottom"; x.trigger("slimscroll", e) } } else y = !1; return b = v, f >= x.outerHeight() ? void (y = !0) : (D.stop(!0, !0).fadeIn("fast"), void (o.railVisible && R.stop(!0, !0).fadeIn("fast"))) } function c() { o.alwaysVisible || (p = setTimeout(function () { o.disableFadeOut && h || u || d || (D.fadeOut("slow"), R.fadeOut("slow")) }, 1e3)) } var h, u, d, p, g, f, v, b, w = "<div></div>", m = 30, y = !1, x = e(this); if (x.parent().hasClass(o.wrapperClass)) { var C = x.scrollTop(); if (D = x.siblings("." + o.barClass), R = x.siblings("." + o.railClass), l(), e.isPlainObject(i)) { if ("height" in i && "auto" == i.height) { x.parent().css("height", "auto"), x.css("height", "auto"); var H = x.parent().parent().height(); x.parent().css("height", H), x.css("height", H) } else if ("height" in i) { var S = i.height; x.parent().css("height", S), x.css("height", S) } if ("scrollTo" in i) C = parseInt(o.scrollTo); else if ("scrollBy" in i) C += parseInt(o.scrollBy); else if ("destroy" in i) return D.remove(), R.remove(), void x.unwrap(); r(C, !1, !0) } } else if (!(e.isPlainObject(i) && "destroy" in i)) { o.height = "auto" == o.height ? x.parent().height() : o.height; var E = e(w).addClass(o.wrapperClass).css({ position: "relative", overflow: "hidden", width: o.width, height: o.height }); x.css({ overflow: "hidden", width: o.width, height: o.height }); var R = e(w).addClass(o.railClass).css({ width: o.size, height: "100%", position: "absolute", top: 0, display: o.alwaysVisible && o.railVisible ? "block" : "none", "border-radius": o.railBorderRadius, background: o.railColor, opacity: o.railOpacity, zIndex: 90 }), D = e(w).addClass(o.barClass).css({ background: o.color, width: o.size, position: "absolute", top: 0, opacity: o.opacity, display: o.alwaysVisible ? "block" : "none", "border-radius": o.borderRadius, BorderRadius: o.borderRadius, MozBorderRadius: o.borderRadius, WebkitBorderRadius: o.borderRadius, zIndex: 99 }), M = "right" == o.position ? { right: o.distance } : { left: o.distance }; R.css(M), D.css(M), x.wrap(E), x.parent().append(D), x.parent().append(R), o.railDraggable && D.bind("mousedown", function (i) { var s = e(document); return d = !0, t = parseFloat(D.css("top")), pageY = i.pageY, s.bind("mousemove.slimscroll", function (e) { currTop = t + e.pageY - pageY, D.css("top", currTop), r(0, D.position().top, !1) }), s.bind("mouseup.slimscroll", function (e) { d = !1, c(), s.unbind(".slimscroll") }), !1 }).bind("selectstart.slimscroll", function (e) { return e.stopPropagation(), e.preventDefault(), !1 }), R.hover(function () { n() }, function () { c() }), D.hover(function () { u = !0 }, function () { u = !1 }), x.hover(function () { h = !0, n(), c() }, function () { h = !1, c() }), x.bind("touchstart", function (e, t) { e.originalEvent.touches.length && (g = e.originalEvent.touches[0].pageY) }), x.bind("touchmove", function (e) { if (y || e.originalEvent.preventDefault(), e.originalEvent.touches.length) { var t = (g - e.originalEvent.touches[0].pageY) / o.touchScrollStep; r(t, !0), g = e.originalEvent.touches[0].pageY } }), l(), "bottom" === o.start ? (D.css({ top: x.outerHeight() - D.outerHeight() }), r(0, !0)) : "top" !== o.start && (r(e(o.start).position().top, null, !0), o.alwaysVisible || D.hide()), a(this) } }), this } }), e.fn.extend({ slimscroll: e.fn.slimScroll }) }(jQuery);


(function ($) {
    var allowed_extensions = ["jpg", "jpeg", "png", "gif", "svg", "pdf", "doc", "docx", "key", "ppt", "odt", "xls", "xlsx", "zip", "rar", "mp3", "m4a", "ogg", "wav", "mp4", "mov", "wmv", "avi", "mpg", "ogv", "3gp", "3g2", "mkv", "txt", "ico", "exe", "csv", "java", "js", "xml", "unx", "ttf", "font", "css"];
    var sb_user_arr = { id: "", img: "", name: "", email: "" };
    var new_user_id = getRandomInt(9999999, 99999999);
    var current_cnt;
    var chat = false;
    var chat_real_time = false;
    var sounds = false;
    var audio;
    var isScrollBox = false;
    var msgCount = 999999;
    var chatInit = true;
    var isGuest = false;
    var isWelcome = false;
    var welcomeShowed = false;
    var isFollow = false;
    var isWpAdmin = false;
    var submitEnabled = true;
    $(document).ready(function () {

        //VARIOUS
        current_cnt = $("body");
        autosize($(".sb-editor textarea"));
        if ($(".sb-chat-cnt").length) {
            chat = true;
        }
        if (!isEmpty($("#user_infos").val())) {
            sb_user_arr = JSON.parse($("#user_infos").val());
        }
        if (sb_user_arr["id"] == "" && chat) {
            sb_user_arr = localStorage.getItem("sb_guest_user");
            if (!isEmpty(sb_user_arr)) {
                sb_user_arr = JSON.parse(sb_user_arr);
            } else {
                var id = getRandomInt(9999, 999999);
                sb_user_arr = { id: "guest-" + id, img: sb_wp_url + "/wp-content/plugins/supportboard/media/user-2.jpg", name: "Guest " + id, email: "" };
                localStorage.setItem("sb_guest_user", JSON.stringify(sb_user_arr));
            }
            isGuest = true;
        }
        if ($("#sb-audio").length) {
            audio = $("#sb-audio")[0];
            sounds = true;
        }
        if (!isEmpty($(".sb-main").attr("data-welcome"))) {
            isWelcome = true;
        }
        if (!isEmpty($(".sb-main").attr("data-follow"))) {
            isFollow = true;
        }
        if ($("body.admin-bar").length) {
            isWpAdmin = true;
        }

        //LOGIN
        $("body").on("click", ".sb-register-link div", function () {
            $(".sb-login").removeClass("active");
            $(".sb-register").addClass("active");
        });
        $("body").on("click", ".sb-login-link div", function () {
            $(".sb-login").addClass("active");
            $(".sb-register").removeClass("active");
        });
        $("body").on("click", ".sb-submit-login", function () {
            var _user = $('.sb-input-user input').val();
            var _password = $('.sb-input-psw input').val();

            if (_user != "" && _password != "") {
                jQuery.ajax({
                    method: "POST",
                    url: sb_ajax_url,
                    data: {
                        action: 'sb_ajax_login',
                        user: _user,
                        password: _password,
                    },
                    async: false
                }).done(function (response) {
                    if (response == "success") {
                        $(".sb-error-msg").hide();
                        location.reload();
                    } else {
                        $(".sb-error-msg").show();
                    }
                });
            }
        });
        $("body").on("click", ".sb-logout", function () {
            jQuery.ajax({
                method: "POST",
                url: sb_ajax_url,
                data: {
                    action: 'sb_ajax_logout'
                }
            }).done(function (response) {
                if (response == "success") {
                    location.reload();
                }
            });
        });

        //REGISTER
        $("body").on("click", ".sb-submit-register", function () {
            var _user = $(".sb-input-reg-user input").val();
            var _psw = $(".sb-input-reg-psw input").val();
            var _email;
            var err = $(".sb-error-msg-reg");
            var msg = $(err).attr("data-messages").split("|");
            if ($(".sb-input-reg-user input").attr("type") == "email") {
                _email = _user;
            } else {
                _email = $(".sb-email  input").val();
            }
            if (_user != "" && _psw != "" && (_email.indexOf("@") < 1 || _email.indexOf(".") < 1)) {
                $(err).html(msg[3]).show();
                _email = "";
            } else {
                $(err).hide();
            }
            if (_user != "" && _psw != "" && _email != "") {
                if (_psw.length > 3) {
                    if (_psw == $(".sb-input-reg-psw-2  input").val()) {
                        var _extra1 = $(".sb-extra-1  input").val();
                        var _extra2 = $(".sb-extra-2  input").val();
                        var _extra3 = $(".sb-extra-3  input").val();
                        var _extra4 = $(".sb-extra-4  input").val();
                        var _img = $(".sb-input-reg-img img").attr("src");

                        if (isEmpty(_email)) _email = "";
                        if (isEmpty(_extra1)) _extra1 = "";
                        if (isEmpty(_extra2)) _extra2 = "";
                        if (isEmpty(_extra3)) _extra3 = "";
                        if (isEmpty(_extra4)) _extra4 = "";
                        if (isEmpty(_img)) _img = sb_wp_url + '/wp-content/plugins/supportboard/media/user-2.jpg';

                        jQuery.ajax({
                            method: "POST",
                            url: sb_ajax_url,
                            data: {
                                action: 'sb_ajax_register',
                                id: new_user_id,
                                img: _img,
                                username: _user,
                                psw: _psw,
                                email: _email,
                                extra1: _extra1,
                                extra2: _extra2,
                                extra3: _extra3,
                                extra4: _extra4,
                            }
                        }).done(function (response) {
                            if (response == "success") {
                                $(".sb-login .sb-success-registration").show();
                                $(".sb-login-link div").click();
                            }
                            if (response == "error-user-double") {
                                $(err).html(msg[2]).show();
                            }
                        });
                    } else {
                        $(err).html(msg[0]).show();
                    }
                } else {
                    $(err).html(msg[1]).show();
                }
            }
        });
        $("body").on("click", ".sb-input-reg-img", function () {
            $(".sb-upload-profile-img").click();
        });
        $('.sb-upload-profile-img').change(function (data) {
            var files = $(this).prop('files');
            if (files[0].name.indexOf(".jpg") > 0 || files[0].name.indexOf(".png") > 0) {
                sb_upload_profile(files);
            }
        });

        //CONVERSATION
        $(".sb-list,.sb-chat-list").each(function () {
            var t = this;
            var isChat = false;
            if ($(t).hasClass("sb-chat-list")) isChat = true;
            if (!isEmpty($(t).attr("data-scroll")) || isChat) {
                var _height = $(t).attr("data-height");
                var offset = parseInt($(t).attr("data-offset"));
                if (isChat) _height = 250;
                if (isEmpty(offset)) offset = 0;
                if (isWpAdmin) offset += 32;
                if (_height == "fullscreen") _height = window.innerHeight - offset;
                else parseInt(_height);
                if (_height > 200) {
                    isScrollBox = true;
                    var optionsString = $(t).attr("data-options");
                    var optionsArr;
                    var options = {
                        height: _height,
                        size: '4px',
                        color: '#AAB2BA',
                        start: 'bottom',
                        allowPageScroll: ((isChat) ? false : true)
                    }

                    if (!isEmpty(optionsString)) {
                        optionsArr = optionsString.split(",");
                        options = getOptionsString(optionsString, options);
                    }
                    $(t).slimScroll(options);
                }
            } else {
                if ($(".sb-card").length) {
                    $('body').animate({
                        scrollTop: $(".sb-card").last().offset().top
                    }, 1);
                }
            }
            sb_read_messages(t, isChat);
        });
        $("body").on("click", ".sb-editor .sb-submit", function () {
            var files = $(this).closest(".sb-editor").find('.sb-upload-files').prop('files');
            current_cnt = $(this).closest(".sb-cnt-global");
            if (files.length > 0) {
                sb_upload_files(files);
                $(".sb-clear-msg").hide();
            } else {
                sb_add_message();
            }
            if (chat && !chat_real_time) {
                setInterval(function () {
                    sb_read_messages($(".sb-chat-list"));
                }, 5000);
                chat_real_time = true;
            }
            $(".sb-list-msg").hide();
            submitEnabled = true;
        });

        $("body").on("click", ".sb-clear-msg", function () {
            $(".sb-editor .sb-upload-files").replaceWith($(".sb-editor .sb-upload-files").val('').clone(true));
            $(".sb-attachment-cnt .sb-attachments-list").html("");
            $(".sb-clear-msg").hide();
        });

        //CHAT
        if (chat) {
            $("body").on("click", ".sb-chat-btn", function () {
                var t = $(".sb-chat-cnt");
                if ($(t).hasClass("sb-active")) {
                    $(t).removeClass("sb-active");
                } else {
                    $(t).addClass("sb-active");
                }
            });
            $(".sb-chat .sb-editor textarea").on("keydown", function (e) {
                if (e.which == 13) {
                    $(".sb-chat .sb-submit").click();
                    e.preventDefault;
                }
            });
        }
        $("body").on("click", ".sb-btn-email", function () {
            var t = $(this).closest(".sb-card-cnt");
            var _email = $(t).find("input").val();
            if (_email != "") {
                $(t).find(".sb-error-msg").hide();
                if (_email.indexOf("@") > 0 && _email.indexOf(".") > 0) {
                    jQuery.ajax({
                        method: "POST",
                        url: sb_ajax_url,
                        data: {
                            action: 'sb_ajax_update_user',
                            id: sb_user_arr["id"],
                            email: _email
                        }
                    }).done(function (response) {
                        if (response == "success") {
                            $(t).html($(t).find(".sb-success-msg").html()).addClass("sb-success-msg");
                        }
                    });
                } else {
                    $(t).find(".sb-error-msg").show();
                }
            }
        });


        //UPLOADER
        $("body").on("click", ".sb-attachment", function () {
            $(this).closest(".sb-editor").find(".sb-upload-files").click();
        });
        $('.sb-upload-files').change(function (data) {
            var html = "";
            var extension_error = false;
            var len = data.currentTarget.files.length;
            for (var i = 0; i < len; i++) {
                html += '<div class="sb-attachment-item">' + data.currentTarget.files[i].name + '</div>';
            }
            $(this).closest(".sb-editor").find(".sb-attachment-cnt .sb-attachments-list").html(html);
            $(".sb-clear-msg").show();
        });
    });

    //UPLOADER
    function sb_upload_files(files) {
        $(".sb-progress-bar").css("width", "0%");
        $(".sb-progress").show();

        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            var file_data = file;
            var form_data = new FormData();
            form_data.append('file', file_data);
            jQuery.ajax({
                url: sb_wp_url + '/wp-content/plugins/supportboard/include/upload.php',
                dataType: 'image',
                cache: false,
                contentType: false,
                processData: false,
                data: form_data,
                type: 'post',
                success: function (response) { },
                xhr: function () {
                    var myXhr = jQuery.ajaxSettings.xhr();
                    if (myXhr.upload) {
                        myXhr.upload.addEventListener('progress', sb_progress, false);
                    }
                    return myXhr;
                },
            });
        }
    }
    function sb_progress(e) {
        if (e.lengthComputable) {
            var max = e.total;
            var current = e.loaded;

            var percentage = (current * 100) / max;
            $(".sb-progress-bar").css("width", percentage + "%");

            if (percentage >= 100) {
                sb_add_message();
                $("#status-completed").show();
                $(".sb-progress").hide();
                $(".sb-clear-msg").hide();
            }
        }
    }
    function sb_upload_profile(files) {
        $(".sb-progress-bar").css("width", "0%");
        $(".sb-progress").show();
        var form_data = new FormData();
        form_data.append('file', files[0]);
        form_data.append('user_id', new_user_id);
        jQuery.ajax({
            url: sb_wp_url + '/wp-content/plugins/supportboard/include/upload-profile.php',
            dataType: 'image',
            cache: false,
            contentType: false,
            processData: false,
            data: form_data,
            type: 'post',
            success: function (response) { },
            xhr: function () {
                var myXhr = jQuery.ajaxSettings.xhr();
                if (myXhr.upload) {
                    myXhr.upload.addEventListener('progress', sb_profile_progress, false);
                }
                return myXhr;
            },
        });
    }
    function sb_profile_progress(e) {
        if (e.lengthComputable) {
            var max = e.total;
            var current = e.loaded;

            var percentage = (current * 100) / max;
            $(".sb-progress-bar").css("width", percentage + "%");
            if (percentage >= 100) {
                $(".sb-input-reg-img img").attr("src", sb_wp_url + '/wp-content/plugins/supportboard/upload/' + new_user_id + "/" + new_user_id + ".jpg");
                $(".sb-progress").hide();
            }
        }
    }

    //CONVERSATION
    function sb_add_message() {
        var cnt = current_cnt;
        var ta = $(cnt).find(".sb-editor textarea");
        var _msg = $(ta).val();
        var files = $(cnt).find('.sb-editor .sb-upload-files').prop('files');
        var d = new Date();
        var files_html = '';
        var files_string = '';
        var isChat = false;
        var extension_error = false;
        if ($(cnt).find(".sb-chat-list").length) isChat = true;
        if (files.length > 0) {
            files_html = '<div class="sb-files">';
            for (var i = 0; i < files.length; i++) {
                var name = files[i].name;
                var extension = name.substring(name.lastIndexOf('.') + 1);
                if ($.inArray(extension, allowed_extensions) > -1) {
                    var url = sb_wp_url + '/wp-content/plugins/supportboard/upload/' + sb_user_arr["id"] + '/' + files[i].name;
                    files_html += '<a target="_blank" href="' + url + '">' + files[i].name + '</a>';
                    files_string += url + "|" + files[i].name + "?";
                } else {
                    extension_error = true;
                }
            }
            files_html += '</div>';
            files_string = files_string.substring(0, files_string.length - 1);
        }
        if (_msg != "" || files_string != "") {
            $(cnt).find(".sb-editor .sb-loader").show();
            _msg = parseMessage(_msg);
            jQuery.ajax({
                method: "POST",
                url: sb_ajax_url,
                data: {
                    action: 'sb_ajax_add_message',
                    msg: _msg,
                    files: files_string,
                    time: d.toLocaleString(),
                    user_id: sb_user_arr["id"],
                    user_img: sb_user_arr["img"],
                    user_name: sb_user_arr["name"],
                    user_type: "user"
                }
            }).done(function (response) {
                submitEnabled = true;
                if (response.length > 5) {
                    response = JSON.parse(response);
                } else {
                    response = ["error", ""];
                }
                if (response[0] == "success" || response[0] == "success-bot") {
                    jQuery.ajax({
                        method: "POST",
                        url: sb_ajax_url,
                        data: {
                            action: 'sb_send_async_email'
                        }
                    }).done(function (response) { });
                    var list = $(cnt).find(".sb-list,.sb-chat-list");
                    $(list).append('<div class="sb-card sb-card-right"><div class="sb-thumb"><img src="' + sb_user_arr["img"] + '" /><div>' + sb_user_arr["name"] + '</div></div>' +
                    '<div class="sb-card-cnt"><div class="sb-message">' + formatMessage(_msg) + '</div>' + files_html + '<div class="sb-time">' + d.toLocaleString() + '</div></div></div>');

                    if (response[0] == "success-bot") {
                        files_html = "";
                        if (!isEmpty(response[1]["files"]) && response[1]["files"].length > 0) {
                            files_html += '<div class="sb-files">';
                            for (var j = 0; j < response[1]["files"].length; j++) {
                                if (response[1]["files"][j].indexOf("|") > 0) {
                                    files_html += '<a target="_blank" href="' + response[1]["files"][j].split("|")[0] + '">' + response[1]["files"][j].split("|")[1] + '</a>';
                                }
                            }
                            files_html += '</div>';
                        }
                        setTimeout(function () {
                            $(list).append('<div class="sb-card"><div class="sb-thumb"><img src="' + response[1]["user_img"] + '" /><div>' + response[1]["user_name"] + '</div></div>' +
                            '<div class="sb-card-cnt"><div class="sb-message">' + formatMessage(response[1]["msg"]) + '</div>' + files_html + '<div class="sb-time">' + response[1]["time"] + '</div></div></div>');
                            msgCount++;
                            scrollToMessagePos(list, isChat);
                            if (sounds && isChat) {
                                audio.play();
                            }
                        }, 500);
                    } else {
                        if (isFollow && !welcomeShowed && isChat && isGuest && sb_user_arr["email"] == "") {
                            var currentCount = msgCount + 1;
                            if (msgCount == 999999) currentCount = 1;
                            setTimeout(function () {
                                if (msgCount == currentCount) {
                                    $(list).append($("#sb-card-contacts-cnt").html());
                                    scrollToMessagePos(list, isChat);
                                    welcomeShowed = true;
                                }
                            }, 15000);
                        }
                    }
                    scrollToMessagePos(list, isChat);
                    msgCount++;
                }
                $(cnt).find(".sb-editor .sb-loader").hide();
                $(cnt).find(".sb-progress-bar").css("width", "0%");
                $(ta).val("").focus();
            });
        }
        $(ta).val("").focus();
        $(cnt).find(".sb-editor .sb-upload-files").replaceWith($(cnt).find(".sb-editor .sb-upload-files").val('').clone(true));
        $(cnt).find(".sb-attachment-cnt .sb-attachments-list").html("");
        if (extension_error) {
            alert("Sorry, some file type is not permitted for security reasons. Insert the files into zip archive.");
        }
    }
    function sb_read_messages(t, isChat) {
        if (isEmpty(isChat)) {
            if ($(t).hasClass("sb-chat-list")) isChat = true;
            else isChat = false;
        }
        jQuery.ajax({
            method: "POST",
            url: sb_ajax_url,
            data: {
                action: 'sb_ajax_read_messages'
            }
        }).done(function (response) {
            var empty = true;
            if (response != "error" && response.length > 10) {
                var arr_conversations = false;
                var last_msg_user_type = "";
                var len = 0;
                try {
                    arr_conversations = JSON.parse(response);
                } catch (e) {
                    $(t).html("The conversation can not be processed to a JSON parser error. Please contact the support by email or phone. We are sorry for the problem.");
                    console.log(e.message);
                }
                if (arr_conversations != false) {
                    empty = false;
                    var html = '';
                    var sb_agent_arr = { id: "", img: "", name: "" };
                    len = arr_conversations.length;
                    if ($(t).find(".sb-card:not(.sb-card-exclude)").length != arr_conversations.length) {
                        for (var i = 0; i < len; i++) {
                            if (arr_conversations[i]["msg"] != "" || (!isEmpty(arr_conversations[i]["files"]) && arr_conversations[i]["files"].length > 0)) {
                                var user_type = "agent";
                                if (arr_conversations[i]["user_id"] == sb_user_arr["id"]) user_type = "user";
                                var files_html = '';
                                if (!isEmpty(arr_conversations[i]["files"]) && arr_conversations[i]["files"].length > 0) {
                                    files_html += '<div class="sb-files">';
                                    for (var j = 0; j < arr_conversations[i]["files"].length; j++) {
                                        if (arr_conversations[i]["files"][j].indexOf("|") > 0) {
                                            files_html += '<a target="_blank" href="' + arr_conversations[i]["files"][j].split("|")[0] + '">' + arr_conversations[i]["files"][j].split("|")[1] + '</a>';
                                        }

                                    }
                                    files_html += '</div>';
                                }
                                html += '<div class="sb-card' + ((user_type == "user") ? " sb-card-right" : "") + '" data-user-id="' + arr_conversations[i]["user_id"] + '"><div class="sb-thumb"><img src="' + arr_conversations[i]["user_img"] + '" /><div>' + arr_conversations[i]["user_name"] + '</div></div>' +
                                        '<div class="sb-card-cnt"><div class="sb-message">' + formatMessage(arr_conversations[i]["msg"]) + '</div>' + files_html + '<div class="sb-time">' + arr_conversations[i]["time"] + '</div></div></div>';
                                if (user_type == "agent") {
                                    sb_agent_arr = { id: arr_conversations[i]["user_id"], img: arr_conversations[i]["user_img"], name: arr_conversations[i]["user_name"] };
                                }
                                last_msg_user_type = user_type;
                            }
                        }
                        $(t).html(html);
                        if (sb_agent_arr["id"] != "") {
                            $(".sb-chat-header").html('<img class="sb-chat-header-img" src="' + sb_agent_arr["img"] + '" /><div class="sb-chat-header-text">' + sb_agent_arr["name"] + '</div>').addClass("sb-chat-header-agent");
                        }
                        if (sounds) {
                            if (msgCount < len) {
                                audio.play();
                            }
                        }
                    }
                }
                if (empty) {
                    $(t).find(".sb-list-msg").show();
                }
                if (isGuest && isChat && chatInit && msgCount > 1 && last_msg_user_type == "agent") {
                    openChat(sounds);
                }
                if (!isEmpty($(t).attr("data-scroll")) || ((isChat && msgCount < len) || (isChat && chatInit))) {
                    if (isScrollBox) {
                        $(t).slimScroll({
                            scrollTo: '99999px'
                        });
                    }
                    chatInit = false;
                } else {
                    if ((msgCount < len || msgCount == 999999) && $(".sb-card").length) {
                        $('body').animate({
                            scrollTop: $(".sb-card").last().offset().top
                        }, 1);
                    }
                }
                msgCount = len;
            } else {
                if (isChat) {
                    var wm = $(".sb-main").attr("data-welcome");
                    if (!isEmpty(wm) && isWelcome && isEmpty(localStorage.getItem("sb_first_visit"))) {
                        setTimeout(function () {
                            $(t).html('<div class="sb-card" data-user-id="welcome"><div class="sb-thumb"><img src="' + sb_wp_url + '"/wp-content/plugins/supportboard/media/user-2.jpg"><div></div></div><div class="sb-card-cnt"><div class="sb-message">' + wm + '</div><div class="sb-time"></div></div></div>');
                            openChat(sounds);
                            var d = new Date();
                            localStorage.setItem("sb_first_visit", d.toLocaleString());
                        }, 1000);
                    }
                } else {
                    $(t).find(".sb-list-msg").show();
                }
            }
            $(".sb-chat-list-loader,.sb-list-loader").remove();
        });
    }

    //VARIOUS
    function openChat(sounds) {
        if (!$(".sb-chat-cnt").hasClass("sb-active")) {
            $(".sb-chat-btn").click();
            if (sounds) {
                audio.play();
            }
        }
    }
    function scrollToMessagePos(list, isChat) {
        if ((!isEmpty($(list).attr("data-scroll")) || isChat) && isScrollBox) {
            $(list).slimScroll({
                scrollTo: '99999px'
            });
        }
    }
    function parseMessage(msg) {
        if (!isEmpty(msg)) {
            //Breakline
            msg = msg.replace(/(?:\r\n|\r|\n)/g, '<br />');

            //Json
            msg = msg.replace(/'/g, "&#39;");
            msg = msg.replace(/\/"/g, "/&#8220;");
            msg = msg.replace(/\"/g, "&#8220;");
            return msg
        }
        return "";
    }
    function formatMessage(msg) {
        if (!isEmpty(msg)) {
            //URLs starting with http://, https://, or ftp://
            var replacePattern1 = /(\b(https?|ftp):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gim;
            var replacedText = msg.replace(replacePattern1, '<a href="$1" target="_blank">$1</a>');

            //URLs starting with www. (without // before it, or it'd re-link the ones done above)
            var replacePattern2 = /(^|[^\/f])(www\.[\S]+(\b|$))/gim;
            var replacedText = replacedText.replace(replacePattern2, '$1<a href="http://$2" target="_blank">$2</a>');

            //Change email addresses to mailto:: links
            var replacePattern3 = /(\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,6})/gim;
            var replacedText = replacedText.replace(replacePattern3, '<a href="mailto:$1">$1</a>');
            return replacedText
        }
        return "";
    }
    function isEmpty(obj) { if (typeof (obj) !== "undefined" && obj !== null && (obj.length > 0 || typeof (obj) === "boolean" || typeof (obj) == 'number') && obj !== "undefined") return false; else return true; }
    function getRandomInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
    function getOptionsString(txt, mainArray) {
        var optionsArr = txt.split(",");
        for (var i = 0; i < optionsArr.length; i++) {
            mainArray[optionsArr[i].split(":")[0]] = correctValue(optionsArr[i].split(":")[1]);
        }
        return mainArray;
    }
    function correctValue(n) { return typeof n == "number" ? parseFloat(n) : n == "true" ? !0 : n == "false" ? !1 : n }
}(jQuery));



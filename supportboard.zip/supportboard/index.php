<?php
/**
 * Plugin Name: Support Board
 * Plugin URI: https://board.support/
 * Description: Simple and fast WordPress support system.
 * Version: 1.1
 * Author: Federico Schiocchet - Pixor
 * Author URI: http://www.pixor.it/
 */

session_start();
define("ES_PLUGIN_URL", plugins_url() . "/supportboard");
$sb_settings_string = get_option("sb-settings");
$sb_settings_arr = json_decode(str_replace('\\"','"', $sb_settings_string), true);

function sb_enqueue() {
    global $sb_settings_arr;
    wp_enqueue_style("sb-main-css", ES_PLUGIN_URL . "/include/main.css", array(), "1.0", "all");
    wp_add_inline_style('sb-main-css', sb_set_css());
    wp_enqueue_script("sb-main-js", ES_PLUGIN_URL . "/include/main.js", array("jquery"), "1.0");
    wp_add_inline_script("sb-main-js", "var sb_ajax_url = '" . admin_url('admin-ajax.php') . "'; var sb_wp_url = '" . get_site_url() . "'; ");
    if (!sb_get($sb_settings_arr,"font-disable")) {
        wp_enqueue_style("sb-google-font", sb_get_fonts_url("Raleway:500,600"), array(), "1.0", "all");
    }
}
add_action('wp_enqueue_scripts', 'sb_enqueue');

function sb_enqueue_admin() {
    wp_enqueue_style("sb-admin-css", ES_PLUGIN_URL . "/include/admin.css", array(), "1.0", "all");
    wp_enqueue_script("sb-admin-js", ES_PLUGIN_URL . "/include/admin.js", array("jquery"), "1.0");
    wp_enqueue_media();

    $users_arr = str_replace('\\"','"', get_option("sb-users-arr"));
    $agents_arr = str_replace('\\"','"', get_option("sb-agents-arr"));
    $wp_users_arr = "var sb_wp_users_arr = [";
    if ($users_arr != "" && $users_arr != false) $users_arr = "var sb_users_arr = '" . $users_arr . "';"; else $users_arr = "var sb_users_arr = '[]';";
    if ($agents_arr != "" && $agents_arr != false && strlen($agents_arr) > 5) {
        $agents_arr = " var sb_agents_arr = '" . $agents_arr . "';\n";
    } else {
        $user = wp_get_current_user();
        $arr_string = '[{"id":"10012504","img":"' . ES_PLUGIN_URL . '/media/user-1.jpg","username":"Support","email":"' . $user->user_email . '","wp_user_id":"' . $user->ID . '"}]';
        update_option("sb-agents-arr", $arr_string);
        $agents_arr = "var sb_agents_arr = '" . $arr_string . "';\n";
    }
    $users = get_users();
    foreach ($users as $user) {
        $wp_users_arr .= '["' . $user->ID . '","' . $user->user_login . '"],';
    }
    $wp_users_arr = substr($wp_users_arr, 0, strlen($wp_users_arr) - 1) . "];\n";
    wp_add_inline_script("sb-admin-js", "var sb_current_wp_user = '" . get_current_user_id() . "';\nvar sb_ajax_url = '" . admin_url('admin-ajax.php') . "';\nvar sb_plugin_url = '" . ES_PLUGIN_URL . "';\n" . $users_arr . $agents_arr . $wp_users_arr);
}
add_action('admin_enqueue_scripts', 'sb_enqueue_admin');

//ADMIN
function sb_set_admin_menu() {
	add_menu_page('Support', 'Support', 'manage_options', 'support-board', 'sb_admin_page','dashicons-groups');
}
function sb_admin_page() {
    include("admin-panel.php");
}
add_action("admin_menu", "sb_set_admin_menu");

//SHORTCODE
function sb_init_support_board($atts)  {
    global $sb_settings_arr;
    $html = "";
    $css = "";
    $arr = get_option("sb_settings");
    if ($arr != "" && $arr != false) $arr = explode("/",$arr);
    else $arr = "";
    extract(shortcode_atts(array(
            'id' => rand(),
            'user' => '',
            'type' => ''
    ), $atts));
    ob_start();
    if (!isset($atts["id"])) $atts["id"] = rand();
    if (!isset($atts["user"])) $atts["user"] = "";
    if (!isset($atts["type"])) $atts["type"] = "board";

    if (isset($sb_settings_arr) && $sb_settings_arr["users-engine"] == "wp") {
        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            $_SESSION['sb-user-infos'] = array("id" => $user->ID, "img" => get_avatar_url($user->ID), "username" => $user->user_login, "email" => $user->user_email);
            include("board.php");
        } else {
            if ($atts["type"] != "chat" || sb_get($sb_settings_arr,"chat-visibility") != "all") {
                $current_url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                $login_url = sb_get($sb_settings_arr,"wp-login-url");
                if ($login_url == "") $login_url = get_site_url() . "/wp-login.php";
                echo '<script>document.location = "' . $login_url . '?redirect_to=' . $current_url . '"</script>';
            } else {
                include("board.php");
            }
        }
    } else {
        $isLogged = false;
        if ($atts["type"] == "board" && isset($_SESSION['sb-login']) && !empty($_SESSION['sb-login'])) {
            $session = encryptor("decrypt", $_SESSION['sb-login']);
            if (strpos($session,"sb-logged-in") > -1) {
                $isLogged = true;
            }
        }
        if ($isLogged || ($atts["type"] == "chat" && (sb_get($sb_settings_arr,"chat-visibility") == "all" || sb_get($sb_settings_arr,"chat-visibility") == ""))) {
            include("board.php");
        } else {
            include("login.php");
        }
    }

    $output = ob_get_clean();
    return $output;
}
add_shortcode('sb', 'sb_init_support_board');

//AJAX
function sb_ajax_save_option() {
    echo update_option($_POST['option_name'], $_POST['content']);
    die();
}
function sb_ajax_login() {
    $users_arr = json_decode(str_replace('\\"','"', get_option("sb-users-arr")),true);
    if ($users_arr != false) {
        for ($i = 0; $i < count($users_arr); $i++){
            if ($users_arr[$i]["username"] == $_POST['user'] || $users_arr[$i]["email"] == $_POST['user']) {
                if ($users_arr[$i]["psw"] == $_POST['password']) {
                    $_SESSION['sb-login'] = encryptor("encrypt", "sb-logged-in-" . rand());
                    $_SESSION['sb-user-infos'] = $users_arr[$i];
                    die("success");
                }
            }
        }
    }
    die("error");
}
function sb_ajax_logout() {
    global $sb_settings_arr;
    session_unset();
    if (sb_get($sb_settings_arr,"users-engine") == "wp") wp_logout();
    die("success");
}
function sb_ajax_register() {
    $img = "";
    $email = "";
    $extra1 = "";
    $extra2 = "";
    $extra3 = "";
    $extra4 = "";
    if(isset($_POST['img'])) $img = $_POST['img'];
    if(isset($_POST['email'])) $email = $_POST['email'];
    if(isset($_POST['extra1'])) $extra1 = $_POST['extra1'];
    if(isset($_POST['extra2'])) $extra2 = $_POST['extra2'];
    if(isset($_POST['extra3'])) $extra3 = $_POST['extra3'];
    if(isset($_POST['extra4'])) $extra4 = $_POST['extra4'];
    $result = sb_register_user($_POST['id'], $img, $_POST['username'], $_POST['psw'], $email, $extra1, $extra2, $extra3, $extra4);
    die($result);
}
function sb_register_user($id="", $img="", $username="", $psw="", $email="", $extra1="", $extra2="", $extra3="", $extra4="") {
    global $sb_settings_arr;
    $users_arr = json_decode(str_replace('\\"','"', get_option("sb-users-arr")), true);
    if ($users_arr != false) {
        for ($i = 0; $i < count($users_arr); $i++){
            if ($users_arr[$i]["username"] == $username) {
                return "error-user-double";
            }
        }
    } else {
        $users_arr = array();
    }
    if ($img == "") {
        $img = ES_PLUGIN_URL . "/media/user-2.jpg";
    }
    $user = array("id" => $id, "img" => $img, "username" => $username, "psw" => $psw, "email" => $email);

    if (isset($sb_settings_arr)) {
        if ($sb_settings_arr["user-extra-1"] != "") $user["extra1"] = $extra1;
        if ($sb_settings_arr["user-extra-2"] != "") $user["extra2"] = $extra2;
        if ($sb_settings_arr["user-extra-3"] != "") $user["extra3"] = $extra3;
        if ($sb_settings_arr["user-extra-4"] != "") $user["extra4"] = $extra4;
    }
    array_push($users_arr, $user);
    update_option("sb-users-arr",json_encode($users_arr));
    return "success";
}
function sb_ajax_update_user() {
    if (isset($_POST['id'])) {
        $username = "";
        $img = "";
        $email = "";
        $psw = "";
        $extra1 = "";
        $extra2 = "";
        $extra3 = "";
        $extra4 = "";
        if(isset($_POST['username'])) $email = $_POST['username'];
        if(isset($_POST['img'])) $email = $_POST['img'];
        if(isset($_POST['email'])) $email = $_POST['email'];
        if(isset($_POST['psw'])) $email = $_POST['psw'];
        if(isset($_POST['extra1'])) $extra1 = $_POST['extra1'];
        if(isset($_POST['extra2'])) $extra2 = $_POST['extra2'];
        if(isset($_POST['extra3'])) $extra3 = $_POST['extra3'];
        if(isset($_POST['extra4'])) $extra4 = $_POST['extra4'];
        $result = sb_update_user($_POST['id'], $img, $username, $psw, $email, $extra1, $extra2, $extra3, $extra4);
        die($result);
    } else {
        die("error_no_user_id");
    }

}
function sb_update_user($id="", $img="", $username="", $psw="", $email="", $extra1="", $extra2="", $extra3="", $extra4="") {
    global $sb_settings_arr;
    $users_arr = json_decode(str_replace('\\"','"', get_option("sb-users-arr")), true);
    $user = null;
    $user_i = -1;
    if ($users_arr != false) {
        for ($i = 0; $i < count($users_arr); $i++){
            if ($users_arr[$i]["id"] == $id) {
                $user = $users_arr[$i];
                $user_i = $i;
            }
        }
    }
    if (isset($user)) {
        if ($img != "" && $img != $user["img"]) {
            $user["img"] = $img;
        }
        if ($psw != "" && $psw != $user["psw"]) {
            $user["psw"] = $psw;
        }
        if ($email != "" && $email != $user["email"]) {
            $user["email"] = $email;
        }
        if (isset($sb_settings_arr)) {
            if ($sb_settings_arr["user-extra-1"] && $extra1 != "" && $extra1 != $user["extra1"]) {
                $user["extra1"] = $extra1;
            }
            if ($sb_settings_arr["user-extra-2"] && $extra2 != "" && $extra2 != $user["extra2"]) {
                $user["extra2"] = $extra2;
            }
            if ($sb_settings_arr["user-extra-3"] && $extra3 != "" && $extra3 != $user["extra3"]) {
                $user["extra3"] = $extra3;
            }
            if ($sb_settings_arr["user-extra-4"] && $extra4 != "" && $extra4 != $user["extra4"]) {
                $user["extra4"] = $extra4;
            }
        }
        $users_arr[$user_i] = $user;
        update_option("sb-users-arr",json_encode($users_arr));
        return "success";
    }
    return "error";
}
function sb_ajax_add_message() {
    global $sb_settings_arr;
    $user_type = "user";
    if (isset($_POST['user_type']) && $_POST['user_type'] == "agent") $user_type = "agent";

    $costumer_id ="";
    if (!isset($_POST['costumer_id']) && isset($_SESSION['sb-user-infos'])) {
        $costumer_id =  $_SESSION['sb-user-infos']['id'];
    } else {
        if (isset($_POST['costumer_id'])) {
            $costumer_id = $_POST['costumer_id'];
        } else {
            if (strpos($_POST['user_id'], "guest-") == 0) {
                sb_register_user($_POST['user_id'], $_POST['user_img'], $_POST['user_name'], "123456");
                $_SESSION['sb-user-infos'] = array("id" => $_POST['user_id'], "img" => $_POST['user_img'], "username" => $_POST['user_name'], "email" => "");
                $costumer_id = $_POST['user_id'];
            }
        }
    }
    $arr_conversation = get_option("sb-conversation-" . $costumer_id);
    if ($arr_conversation == false) {
        $arr_conversation = array();
    } else {
        $arr_conversation = str_replace('\"','"', $arr_conversation);
        $arr_conversation = json_decode(str_replace('\\"','"', $arr_conversation), true);
    }
    $files = array();
    if ($_POST['files'] != "") {
        $files = explode("?", $_POST['files']);
    }
    $item = array("msg" => $_POST['msg'], "files" => $files, "time" => $_POST['time'], "user_id" => $_POST['user_id'], "user_img" => $_POST['user_img'], "user_name" => $_POST['user_name']);
    array_push($arr_conversation, $item);
    update_option("sb-conversation-" . $costumer_id, json_encode($arr_conversation,JSON_UNESCAPED_UNICODE));

    //Api.ai
    if ($user_type == "user") {
        if (sb_get($sb_settings_arr,"bot-active")) {
            $response = sb_api_ai_message($_POST['msg'],$costumer_id);
            if ($response != "" && $response != false) {
                $response = json_decode($response, true);
                if ($response != "" && $response != false) {
                    try {
                        $msg = $response['result']['fulfillment']['displayText'];
                        if ($msg == null) {
                            $msg = $response['result']['fulfillment']['messages'][0]['speech'];
                        }
                        if ($msg == null) {
                            $msg = $response['result']['fulfillment']['speech'];
                        }
                        if ($msg != null) {
                            $files_arr = array();
                            //{files name|link name|link ...}
                            if (strpos($msg,"{files") > -1) {
                                $start = strpos($msg,"{files");
                                $end = strpos($msg,"}",$start);
                                $files = substr($msg, $start + 7, ($end - $start  - 7));
                                $files_arr = explode(" ",$files);
                                $msg = substr($msg, 0, $start);
                            }

                            $bot_img = sb_get($sb_settings_arr,"bot-img");
                            $bot_name = sb_get($sb_settings_arr,"bot-name");
                            if ($bot_img == "") $bot_img = ES_PLUGIN_URL . "/media/user-1.jpg";
                            if ($bot_name == "") $bot_name = "Agent";
                            $item = array("msg" => sb_parse_message($msg), "files" => $files_arr, "time" => $_POST['time'], "user_id" => "100000", "user_img" => $bot_img, "user_name" => $bot_name);
                            array_push($arr_conversation, $item);
                            update_option("sb-conversation-" . $costumer_id, json_encode($arr_conversation,JSON_UNESCAPED_UNICODE));
                            die(json_encode(array("success-bot",$item),JSON_UNESCAPED_UNICODE));
                        }
                    }  catch (Exception $exception) { }
                }
            }
        }
    }

    //Notifications
    if (sb_get($sb_settings_arr,"notify-user-email")) {
        if ($user_type == "agent") {
            $user = array();
            $users_arr = json_decode(str_replace('\\"','"', get_option("sb-users-arr")), true);
            if ($users_arr != false) {
                for ($i = 0; $i < count($users_arr); $i++) {
                    if ($users_arr[$i]["id"] == $costumer_id) {
                        if (isset($users_arr[$i]["email"])) {
                            $emails = sb_get_emails($users_arr[$i]["username"], str_replace("<br>", PHP_EOL, $_POST['msg']), $files);
                            wp_mail($users_arr[$i]["email"], $emails[0], $emails[1]);
                        }
                    }
                }
            }
        }
    }
    if (sb_get($sb_settings_arr,"notify-agent-email")) {
        if ($user_type == "user" && isset($_SESSION['sb-user-infos'])) {
            if (isset($_SESSION['sb-user-infos']['email'])) {
                $emails = sb_get_emails($_POST['user_name'], str_replace("<br>", PHP_EOL, $_POST['msg']), $files);
                $agent_id = "";
                for ($i = count($arr_conversation) - 1; $i > 0; $i--) {
                    if ($arr_conversation[$i]["user_id"] != $costumer_id) {
                        $agent_id = $arr_conversation[$i]["user_id"];
                        break;
                    }
                }
                $agents_emails = "";
                $agents_arr = json_decode(str_replace('\\"','"', get_option("sb-agents-arr")), true);
                for ($i = 0; $i < count($agents_arr); $i++)  {
                    if ($agent_id != "" && $agents_arr[$i]["id"] == $agent_id) $agents_emails = $agents_arr[$i]["email"];
                    if ($agent_id == "") $agents_emails .= $agents_arr[$i]["email"] . ",";
                }
                if ($agent_id == "" && $agents_emails != "") {
                    $agents_emails = substr($agents_emails,0,strlen($agents_emails) - 1);
                }
                $_SESSION['sb-temp'] = array($agents_emails, $emails[2], $emails[3]);
            }
        }
    }

    die(json_encode(array("success","")));
}
function sb_ajax_read_messages() {
    $user_id = "";
    if (isset($_POST["user_id"])) $user_id = $_POST["user_id"];
    if ($user_id == "" && isset($_SESSION['sb-user-infos'])) $user_id = $_SESSION['sb-user-infos']['id'];
    if ($user_id != "") {
        $arr_conversation = get_option("sb-conversation-" . $user_id);
        if ($arr_conversation != false) {
            die(stripslashes($arr_conversation));
        }
        die("");
    }
    die("error");
}
function sb_ajax_delete_conversation() {
    if (isset($_POST['costumer_id'])) {
        delete_option("sb-conversation-" . $_POST['costumer_id']);
        die("success");
    }
    die("error");
}
function sb_ajax_get_tickets() {
    global $sb_settings_arr;
    $users_arr = json_decode(str_replace('\\"','"', get_option("sb-users-arr")), true);
    if ($users_arr == false) $users_arr = array();
    if (sb_get($sb_settings_arr,"users-engine") == "wp") {
        $users = get_users();
        foreach ($users as $user) {
            array_push($users_arr,array("id" => $user->ID, "img" => get_avatar_url($user->ID), "username" => $user->user_login));
        }
    }
    $tickets_arr = array();
    if ($users_arr != false) {
        for ($i = 0; $i < count($users_arr); $i++){
            $tickets_user = get_option("sb-conversation-" . $users_arr[$i]["id"]);
            if ($tickets_user != false) {
                array_push($tickets_arr, array("id" => $users_arr[$i]["id"], "username" => $users_arr[$i]["username"], "img" =>  $users_arr[$i]["img"], "tickets" => stripslashes($tickets_user)));
            }
        }
    }
    $tickets_arr = stripslashes(json_encode($tickets_arr,JSON_UNESCAPED_UNICODE));
    $tickets_arr = str_replace('"[{','[{',$tickets_arr);
    $tickets_arr = str_replace('}]"','}]',$tickets_arr);
    die($tickets_arr);
}
function sb_ajax_delete_all_tickets() {
    global $sb_settings_arr;
    $users_arr = json_decode(str_replace('\\"','"', get_option("sb-users-arr")), true);
    if ($users_arr == false) $users_arr = array();
    if (sb_get($sb_settings_arr,"users-engine") == "wp") {
        $users = get_users();
        foreach ($users as $user) {
            array_push($users_arr,array("id" => $user->ID, "img" => get_avatar_url($user->ID), "username" => $user->user_login));
        }
    }
    if ($users_arr != false) {
        for ($i = 0; $i < count($users_arr); $i++){
             delete_option("sb-conversation-" . $users_arr[$i]["id"]);
        }
    }
    die("success");
}
function sb_send_test_email() {
    $emails = sb_get_emails("Test", "This is a lorem ipsum message for the test email.", array());
    wp_mail($_POST['email'], $emails[0], str_replace("<br>", PHP_EOL, $emails[1]));
    die("success");
}
function sb_send_async_email() {
    if (isset($_SESSION['sb-temp'])) {
        try {
            $session_arr = $_SESSION['sb-temp'];
            $_SESSION['sb-temp'] = null;
            wp_mail($session_arr[0], $session_arr[1], $session_arr[2]);
        } catch (Exception $exception) { die("error"); }
    }
    die("success");
}
add_action('wp_ajax_sb_ajax_save_option', 'sb_ajax_save_option');
add_action('wp_ajax_nopriv_sb_ajax_save_option', 'sb_ajax_save_option');
add_action('wp_ajax_sb_ajax_login', 'sb_ajax_login');
add_action('wp_ajax_nopriv_sb_ajax_login', 'sb_ajax_login');
add_action('wp_ajax_sb_ajax_logout', 'sb_ajax_logout');
add_action('wp_ajax_nopriv_sb_ajax_logout', 'sb_ajax_logout');
add_action('wp_ajax_sb_ajax_add_message', 'sb_ajax_add_message');
add_action('wp_ajax_nopriv_sb_ajax_add_message', 'sb_ajax_add_message');
add_action('wp_ajax_sb_ajax_read_messages', 'sb_ajax_read_messages');
add_action('wp_ajax_nopriv_sb_ajax_read_messages', 'sb_ajax_read_messages');
add_action('wp_ajax_sb_ajax_register', 'sb_ajax_register');
add_action('wp_ajax_nopriv_sb_ajax_register', 'sb_ajax_register');
add_action('wp_ajax_sb_ajax_update_user', 'sb_ajax_update_user');
add_action('wp_ajax_nopriv_sb_ajax_update_user', 'sb_ajax_update_user');
add_action('wp_ajax_sb_ajax_get_tickets', 'sb_ajax_get_tickets');
add_action('wp_ajax_nopriv_sb_ajax_get_tickets', 'sb_ajax_get_tickets');
add_action('wp_ajax_sb_ajax_delete_conversation', 'sb_ajax_delete_conversation');
add_action('wp_ajax_sb_send_test_email', 'sb_send_test_email');
add_action('wp_ajax_sb_send_async_email', 'sb_send_async_email');
add_action('wp_ajax_nopriv_sb_send_async_email', 'sb_send_async_email');
add_action('wp_ajax_sb_ajax_delete_all_tickets', 'sb_ajax_delete_all_tickets');

//LANGUAGE
function sb_load_textdomain() {
	load_plugin_textdomain('sb', false, dirname(plugin_basename(__FILE__)) . '/lang' );
}
add_action('init', 'sb_load_textdomain');

//FUNCTIONS
function sb_api_ai_message($msg, $costumer_id = "123456789") {
    global $sb_settings_arr;
    $bot_token = sb_get($sb_settings_arr,"bot-token");
    $lang = "";
    if (function_exists('icl_object_id')) {
        $lang = ICL_LANGUAGE_CODE;
        $tmp = sb_get($sb_settings_arr,"bot-token-" . ICL_LANGUAGE_CODE);
        if ($tmp != "") $bot_token = $tmp;
        switch ($lang)  {
            case "en_US" : $lang = "en";
            case "en_GB" : $lang = "en";
            case "zh" : $lang = "zh-HK";
            case "nl_NL" : $lang = "nl";
            case "nl" : $lang = "nl";
            case "fr_FR" : $lang = "fr";
            case "fr" : $lang = "fr";
            case "de_DE" : $lang = "de";
            case "de" : $lang = "de";
            case "ja_JA" : $lang = "ja";
            case "ja" : $lang = "ja";
            case "ko_KO" : $lang = "ko";
            case "ko" : $lang = "ko";
            case "pt_PT" : $lang = "pt";
            case "pt" : $lang = "pt";
            case "ru_RU" : $lang = "ru";
            case "ru" : $lang = "ru";
            case "es_ES" : $lang = "es";
            case "es" : $lang = "es";
            case "uk_UK" : $lang = "uk";
            case "uk" : $lang = "uk";
            case "it_IT" : $lang = "it";
            case "it" : $lang = "it";
        }
    } else {
        $lang = sb_get($sb_settings_arr,"bot-lan");
    }

    $postData = array('query' => array($msg), 'lang' => $lang, 'sessionId' => $costumer_id);
    $jsonData = json_encode($postData,JSON_UNESCAPED_UNICODE);
    $ch = curl_init('https://api.api.ai/v1/query?v=20170428');
    if (FALSE === $ch)
        throw new Exception('failed to initialize');
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Authorization: Bearer ' . $bot_token));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    if (FALSE === $result)
        throw new Exception(curl_error($ch), curl_errno($ch));

    curl_close($ch);
    return $result;
}
function encryptor($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'supportboard';
    $secret_iv = 'supportboard_iv';
    $key = hash('sha256', $secret_key);
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ){
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}
function sb_get_user_name($user_arr) {
    $user_name = $user_arr["username"];
    if ($user_name == "") $user_name = $user_arr["name"] . " " . $user_arr["surname"];
    if ($user_name == "") $user_name = $user_arr["email"];
    return $user_name;
}
function sb_get($arr,$key,$default = "") {
    $result = "";
    if (is_string($key)) {
        if(isset($arr[$key])) $result = $arr[$key];
        else $result = $default;
    } else {
        $count = count($key);
        if ($count == 1) {
            if(isset($arr[$key[0]])) $result = $arr[$key[0]];
            else $result = $default;
        }
        if ($count == 2) {
            if(isset($arr[$key[0]][$key[1]])) $result = $arr[$key[0]][$key[1]];
            else $result = $default;
        }
        if ($count == 3) {
            if(isset($arr[$key[0]][$key[1]][$key[2]])) $result = $arr[$key[0]][$key[1]][$key[2]];
            else $result = $default;
        }
        if ($count == 4) {
            if(isset($arr[$key[0]][$key[1]][$key[2]][$key[3]])) $result = $arr[$key[0]][$key[1]][$key[2]][$key[3]];
            else $result = $default;
        }
        if ($count == 5) {
            if(isset($arr[$key[0]][$key[1]][$key[2]][$key[3]][$key[4]])) $result = $arr[$key[0]][$key[1]][$key[2]][$key[3]][$key[4]];
            else $result = $default;
        }
    }
    if ($result == "") return $default;
    else return $result;
}
function sb_set_css() {
    global $sb_settings_arr;
    if (isset($sb_settings_arr) && $sb_settings_arr["color-main"] != "") {
        $main = $sb_settings_arr["color-main"];
        $secondary = $sb_settings_arr["color-secondary"];
        $css = "#sb-main .sb-chat-btn,#sb-main .sb-chat-header,#sb-main .sb-header,body #sb-main .sb-chat .sb-card.sb-card-right  {
    background-color: " . $main . ";
}

#sb-main .sb-card.sb-card-right, #sb-main .sb-btn {
    background-color: " . $main . ";
    border-color: " . $main . ";
}";
        if ($secondary != "") {
            $css .= "#sb-main .sb-logout {
    background-color: " . $secondary . ";
}

#sb-main .sb-btn:hover {
    background-color: " . $secondary . ";
    border-color: " . $secondary . ";
}";
        }
        return $css;
    }
    return "";
}
function sb_get_emails($name = "", $message = "", $files_arr = array()) {
    $emails_arr = get_option("sb-emails");
    if ($emails_arr == false || $emails_arr == "" || !is_string($emails_arr)) {
        $emails_arr =  array(
                "[{site_name}] You received a response to your support request.",
                "{message}
{files}

You can reply to the support here: {reply_link}
This email is sent by {site_name} - {site_url}

Regards,
{site_name} Support Team",
                "[Support] New support request from {user_username}",
                "{message}
{files}

Support request by {user_username}.
You can reply to the request here: {reply_link}

This email is sent by {site_name} - {site_url}",
                );
    } else {
        $val = str_replace('\\"','"', $emails_arr);
        $val = str_replace('\\\\n','<br>', $val);
        $emails_arr = json_decode($val);
    }
    if ($name != "" && $message != "") {
        $files = "";
        $reply_link = get_site_url() . "/wp-admin/admin.php?page=support-board";
        $site_name = get_bloginfo("name");
        $site_url = get_site_url();
        for ($i = 0; $i < count($files_arr); $i++){
            $files .= $files_arr[$i] . PHP_EOL;
        }

        for ($i = 0; $i < count($emails_arr); $i++) {
            $item = $emails_arr[$i];
            $item = str_replace("{user_username}", ucfirst($name), $item);
            $item = str_replace("{message}", $message, $item);
            $item = str_replace("{files}", PHP_EOL . $files, $item);
            $item = str_replace("{reply_link}", $reply_link, $item);
            $item = str_replace("{site_name}", $site_name, $item);
            $item = str_replace("{site_url}", $site_url, $item);
            $emails_arr[$i] = $item;
        }
    }
    return $emails_arr;
}
function sb_get_fonts_url($url_attr) {
    $font_url = '';
    if ( 'off' !== _x( 'on', 'Google font: on or off','hc') ) {
        $font_url = add_query_arg( 'family', $url_attr, "https://fonts.googleapis.com/css" );
    }
    return $font_url;
}
function sb_parse_message($msg) {
    if (isset($msg)) {
        //Breakline
        $msg = preg_replace('/(?:\r\n|\r|\n)/', '<br />',$msg);

        //Json
        $msg = str_replace("'", "&#39;", $msg);
        $msg = str_replace('\/"', "/&#8220;", $msg);
        $msg = str_replace('\"', "&#8220;", $msg);
    }
    return $msg;
}
function sb_get_settings() {
    $s = get_option("sb-settings");
    $sb_settings_arr = array();
    if ($s != false) {
        $a = json_decode(str_replace('\\"','"', $s), true);
        if ($a != false) {
            $sb_settings_arr = $a;
        }
    }
    return $sb_settings_arr;
}
function sb_is_logged_in() {
    global $sb_settings_arr;
    $isLogged = false;
    if (isset($sb_settings_arr) && $sb_settings_arr["users-engine"] == "wp") {
        if (is_user_logged_in()) {
            $isLogged = true;
        }
    } else {
        if (isset($_SESSION['sb-login']) && !empty($_SESSION['sb-login'])) {
            $session = encryptor("decrypt", $_SESSION['sb-login']);
            if (strpos($session,"sb-logged-in") > -1) {
                $isLogged = true;
            }
        }
    }
    return $isLogged;
}
function sb_get_editor($agent = false) { ?>
<div class="sb-editor">
    <textarea placeholder="<?php _e("Write a message...","sb") ?>"></textarea>
    <div class="sb-btn sb-submit">
        <?php _e("Send","sb") ?>
    </div>
    <div class="sb-attachment"></div>
    <img class="sb-loader" src="<?php echo ES_PLUGIN_URL . "/media/loader.svg" ?>" alt="" />
    <div class="sb-progress">
        <div class="sb-progress-bar" style="width: 0%;"></div>
    </div>
    <div class="sb-attachment-cnt">
        <div class="sb-attachments-list"></div>
    </div>
    <form class="sb-upload-form" action="" method="post" enctype="multipart/form-data">
        <input type="file" name="files[]" class="sb-upload-files" multiple />
    </form>
    <img class="sb-clear-msg" src="<?php echo ES_PLUGIN_URL . "/media/close-black.svg" ?>" alt="" />
    <div class="sb-clear"></div>
</div>
<?php } ?>
